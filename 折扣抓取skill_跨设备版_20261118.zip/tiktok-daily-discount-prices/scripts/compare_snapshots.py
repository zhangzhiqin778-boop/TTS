import json,re,sys
from pathlib import Path
from decimal import Decimal

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).parent
def load(filename):return json.loads((root/filename).read_text(encoding='utf-8'))
def money(text):
    m=re.search(r'\$([\d,.]+)',text)
    return str(Decimal(m.group(1).replace(',','')).quantize(Decimal('.01'))) if m else None
def parse(rows):
    products={r['id'][4:]:{'name':r['cells'][1].split('\nID')[0],'status':r['cells'][7],'expected':int(re.search(r'(\d+) SKUs?',r['group']).group(1))} for r in rows if r.get('group')}
    skus={}
    for r in rows:
        if not r.get('prefill'):continue
        _,pid,sid=r['prefill'].split('__');key=pid+'|'+sid
        if key in skus:raise ValueError('Duplicate SKU '+key)
        p=products[pid];d=r.get('discount')
        skus[key]={'pid':pid,'sid':sid,'spec':r['cells'][1],'original':money(r['cells'][2]),'price':money(r['cells'][3]),'rate':str(Decimal(d).normalize()) if d and d.strip() else None,'enabled':r.get('enabled')=='true','stock':int(r['cells'][4]),'product_status':p['status'],'product_name':p['name'],'capturedAt':r.get('capturedAt')}
    for pid,p in products.items():
        assert sum(s['pid']==pid for s in skus.values())==p['expected'],pid
    return products,skus

oldstatus,newstatus=load('baseline-status.json'),load('collector-status.json')
assert all(s['state']=='complete' and not s['incomplete'] for s in [oldstatus,newstatus])
assert oldstatus['shop']==newstatus['shop'] and oldstatus['activityId']==newstatus['activityId']
op,old=parse(load('baseline-raw.json'));np,new=parse(load('raw.json'))
labels={'original':'原价','price':'折扣价','rate':'折扣比例','enabled':'SKU启用','spec':'规格','product_status':'商品状态','product_name':'商品名称','stock':'库存'}
changes=[]
for key in sorted(old.keys()|new.keys()):
    a,b=old.get(key),new.get(key)
    fields=[f for f in labels if a and b and a[f]!=b[f]]
    if not a or not b or fields:
        changes.append({'key':key,'kind':'新增' if not a else '移除' if not b else '变更','fields':fields,'field_labels':[labels[f] for f in fields],'before':a,'after':b})
main=[d for d in changes if d['kind']!='变更' or any(f!='stock' for f in d['fields'])]
stockonly=[d for d in changes if d['kind']=='变更' and d['fields']==['stock']]
summary={'shop':newstatus['shop'],'activity_id':newstatus['activityId'],'baseline_finish_utc':oldstatus['finishedAt'],'current_finish_utc':newstatus['finishedAt'],'baseline_products':len(op),'current_products':len(np),'baseline_sku':len(old),'current_sku':len(new),'changed_sku':len(changes),'price_or_status_sku':len(main),'stock_only_sku':len(stockonly),'new_sku':sum(d['kind']=='新增' for d in changes),'removed_sku':sum(d['kind']=='移除' for d in changes),'fields':{label:sum(field in d['fields'] for d in changes) for field,label in labels.items()}}
result={'summary':summary,'changes':changes,'main':main,'stock_only':stockonly,'current':list(new.values())}
(root/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
print(json.dumps(main[:30],ensure_ascii=False))

