import fs from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import {createRequire} from 'node:module';
const runtimeModules=process.argv[3];
const {Workbook,SpreadsheetFile}=runtimeModules?createRequire(path.join(path.dirname(runtimeModules),'skill-runtime.cjs'))('@oai/artifact-tool'):await import('@oai/artifact-tool');
const root=process.argv[2]?pathToFileURL(path.resolve(process.argv[2])+path.sep):new URL('.',import.meta.url);
const data=JSON.parse(await fs.readFile(new URL('comparison.json',root),'utf8'));
const wb=Workbook.create();
const diff=wb.worksheets.add('差异SKU');
const latest=wb.worksheets.add('最新SKU价格');
const notes=wb.worksheets.add('对比说明');
const num=v=>v==null?null:Number(v);
const rate=v=>v==null?null:Number(v)/100;
const yn=v=>v==null?null:v?'启用':'未启用';
const literal=v=>typeof v==='string'&&/^[=+@]/.test(v)?"'"+v:v;
function grid(s,headers,rows,widths,start=1,name='Data'){
  s.showGridLines=false;
  const values=[headers,...rows].map(r=>r.map(literal));
  s.getRangeByIndexes(start-1,0,values.length,headers.length).values=values;
  const range=s.getUsedRange();range.format.font={name:'Arial',size:10};range.format.verticalAlignment='center';
  range.format.rowHeight=32;
  for(let i=0;i<headers.length;i++)s.getRangeByIndexes(start-1,i,values.length,1).format.columnWidthPx=widths[i]??125;
  s.getRangeByIndexes(start-1,0,1,headers.length).format={fill:'#243B53',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:34,wrapText:true,horizontalAlignment:'center'};
  s.tables.add(s.getRangeByIndexes(start-1,0,values.length,headers.length),true,name);
  s.freezePanes.freezeRows(start);
}
const diffHeaders=['Product ID','SKU ID','规格','变化字段','原价 USD','上次折扣价 USD','本次折扣价 USD','价格变动 USD','上次折扣比例','本次折扣比例','上次库存','本次库存','上次SKU状态','本次SKU状态','上次商品状态','本次商品状态','商品名称','变化类型'];
const diffs=data.changes.map(d=>{const a=d.before,b=d.after,s=b??a;return[s.pid,s.sid,s.spec,d.field_labels.join('、'),num(s.original),num(a?.price),num(b?.price),a?.price!=null&&b?.price!=null?Number((Number(b.price)-Number(a.price)).toFixed(2)):null,rate(a?.rate),rate(b?.rate),a?.stock??null,b?.stock??null,yn(a?.enabled),yn(b?.enabled),a?.product_status??null,b?.product_status??null,s.product_name,d.kind];});
grid(diff,diffHeaders,diffs,[185,185,390,170,120,150,150,150,150,150,100,100,140,140,160,160,600,100],5,'ChangedSkuTable');
diff.getRange('A2').values=[['日常折扣价格对比']];diff.getRange('A2').format.font={name:'Arial',size:14,bold:true};
diff.getRange('A3').values=[[`共 ${data.summary.changed_sku} 个SKU有变化；比较覆盖 ${data.summary.current_products} 个活动商品、${data.summary.current_sku} 个SKU`]];
if(diffs.length){
diff.getRange(`C6:D${5+diffs.length}`).format.wrapText=true;
diff.getRange(`C6:D${5+diffs.length}`).format.rowHeight=68;
diff.getRange(`E6:H${5+diffs.length}`).setNumberFormat('0.00');diff.getRange(`I6:J${5+diffs.length}`).setNumberFormat('0%');
diff.getRange(`Q6:Q${5+diffs.length}`).format.wrapText=true;diff.getRange(`Q6:Q${5+diffs.length}`).format.rowHeight=86;
}
const current=data.current.map(s=>[s.pid,s.sid,s.spec,num(s.original),num(s.price),rate(s.rate),s.stock,yn(s.enabled),s.product_status,s.product_name,new Date(s.capturedAt)]);
grid(latest,['Product ID','SKU ID','规格','原价 USD','折扣价 USD','折扣比例','库存','SKU状态','商品状态','商品名称','读取时间 UTC'],current,[185,185,390,120,120,120,90,120,160,600,190],1,'CurrentSkuTable');
latest.getRange(`D2:E${current.length+1}`).setNumberFormat('0.00');latest.getRange(`F2:F${current.length+1}`).setNumberFormat('0%');latest.getRange(`K2:K${current.length+1}`).setNumberFormat('yyyy-mm-dd hh:mm:ss');
latest.getRange(`C2:C${current.length+1}`).format.wrapText=true;latest.getRange(`J2:J${current.length+1}`).format.wrapText=true;latest.getRange(`J2:J${current.length+1}`).format.rowHeight=80;
const local=t=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'short',timeStyle:'medium',hour12:false}).format(new Date(t));
const s=data.summary;
const noteRows=[['店铺',s.shop],['活动ID',s.activity_id],['基准采集完成时间（北京时间）',local(s.baseline_finish_utc)],['本次采集完成时间（北京时间）',local(s.current_finish_utc)],['基准商品数 / 本次商品数',`${s.baseline_products} / ${s.current_products}`],['基准SKU数 / 本次SKU数',`${s.baseline_sku} / ${s.current_sku}`],['差异SKU数',s.changed_sku],['价格或状态等差异SKU数',s.price_or_status_sku],['仅库存变化SKU数',s.stock_only_sku],['新增SKU数',s.new_sku],['移除SKU数',s.removed_sku],['匹配键','同一店铺和活动下按Product ID + SKU ID精确匹配'],['比较字段','原价、活动折扣价、折扣比例、SKU启用、规格、库存、商品状态、商品名称'],['忽略字段','采集时间、滚动顺序、Updated页面提示，不作为业务差异'],['金额及空值','同币种USD比较，金额精确到分。未启用SKU的空折扣价与比例保持空值，不按0处理。'],['覆盖范围','同一指定活动；商品和SKU数量见上方，不包括全店未参加活动的商品。'],['源活动页面','https://seller-us.tiktok.com/promotion/marketing-tools/discount/edit/7675921274784794381?back=1&shop_region=US'],['基准报告','baseline-report.xlsx（先前已完整核验的报告副本）'],['基准与新快照','baseline-raw.json / raw.json；与报告放在同一结果目录，原基准报告未覆盖。']];
grid(notes,['项目','说明'],noteRows,[300,1150],1,'ComparisonNotes');notes.getRange(`B2:B${noteRows.length+1}`).format.wrapText=true;notes.getRange(`B2:B${noteRows.length+1}`).format.rowHeight=40;
wb.recalculate();
console.log((await wb.inspect({kind:'table',range:'差异SKU!C5:P6',tableMaxRows:2,tableMaxCols:14,maxChars:2200})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:1000})).ndjson);
for(const [sheet,range,file] of [['差异SKU','C5:L6','diff-preview.png'],['最新SKU价格','C1:I7','current-preview.png'],['对比说明','A1:B12','notes-preview.png']]){const p=await wb.render({sheetName:sheet,range,scale:1,format:'png'});await fs.writeFile(new URL(file,root),new Uint8Array(await p.arrayBuffer()));}
await (await SpreadsheetFile.exportXlsx(wb)).save(fileURLToPath(new URL('Arabellahair_日常折扣价格_新旧差异.xlsx',root)));
console.log(JSON.stringify(s));


