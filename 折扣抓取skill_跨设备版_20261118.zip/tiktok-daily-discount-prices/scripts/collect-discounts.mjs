import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
const runtimeModules=process.argv[3];
const {chromium}=runtimeModules?createRequire(path.join(path.dirname(runtimeModules),'skill-runtime.cjs'))('playwright'):await import('playwright');

const root=path.resolve(process.argv[2]??path.join(process.cwd(),'outputs','daily-discount-'+new Date().toISOString().replaceAll(':','-')));
await fs.mkdir(root,{recursive:true});
const target='https://seller-us.tiktok.com/promotion/marketing-tools/discount/edit/7702725505513981710?back=1&shop_region=US';
const checkpoint=path.join(root,'raw.json');
const statusFile=path.join(root,'collector-status.json');
const browserDir=process.argv[4]?path.resolve(process.argv[4]):path.join(root,'.browser-profile');
const records=new Map();
const resume=process.argv.includes('--resume');
try {
  const existing=JSON.parse(await fs.readFile(checkpoint,'utf8'));
  if(!resume)throw new Error('Output already contains raw.json. Choose a fresh output directory, or explicitly pass --resume for an interrupted run.');
  const previous=JSON.parse(await fs.readFile(statusFile,'utf8'));
  if(previous.state==='complete')throw new Error('Completed snapshots are immutable. Use a fresh output directory.');
  for(const r of existing)records.set(r.id,r);
}catch(e){if(e.code!=='ENOENT')throw e;}
const seenRows=new Set();
const seenProducts=new Set();
const status={state:'starting',activityId:'7702725505513981710',startedAt:new Date().toISOString(),steps:0};
async function persist(){
  const items=[...records.values()];
  const products=items.filter(r=>r.group);
  const skus=items.filter(r=>r.prefill);
  status.discoveredProducts=products.length;status.sku=skus.length;
  status.productsReadThisRun=seenProducts.size;
  status.incomplete=products.map(p=>({productId:p.id.slice(4),expected:Number(p.group.match(/(\d+) SKUs?/)?.[1]??0),captured:skus.filter(s=>s.id.startsWith(p.id)).length})).filter(p=>p.expected!==p.captured);
  status.updatedAt=new Date().toISOString();
  await fs.writeFile(checkpoint+'.tmp',JSON.stringify(items,null,2));
  await fs.rename(checkpoint+'.tmp',checkpoint);
  await fs.writeFile(statusFile,JSON.stringify(status,null,2));
  console.log(JSON.stringify({state:status.state,products:status.discoveredProducts,sku:status.sku,incomplete:status.incomplete.length,step:status.steps}));
}
await fs.writeFile(path.join(root,'.gitignore'),'.browser-profile/\n');
const context=await chromium.launchPersistentContext(browserDir,{channel:'chrome',headless:false,viewport:{width:1600,height:1000},acceptDownloads:true});
const page=context.pages()[0]??await context.newPage();
async function waitForVerification(){
  const challenge=page.locator('#captcha_container');
  if(await challenge.isVisible()){
    status.state='waiting_for_verification';await persist();
    console.log('Please complete the verification manually in the dedicated Chrome window. The collector will resume automatically.');
    await challenge.waitFor({state:'hidden',timeout:900000});
    status.state='collecting';await persist();
  }
}
async function readOnlyClick(locator){
  await waitForVerification();
  try {await locator.click({timeout:15000});}
  catch(e){if(await page.locator('#captcha_container').isVisible()){await waitForVerification();await locator.click({timeout:15000});}else throw e;}
}
async function capture(){
  await waitForVerification();
  if(!page.url().startsWith('https://seller-us.tiktok.com/promotion/marketing-tools/discount/edit/7702725505513981710'))throw new Error('Unexpected page URL; collection stopped.');
  const b=await page.locator('.theme-arco-table-body').first().evaluate(body=>({top:body.scrollTop,height:body.clientHeight,total:body.scrollHeight,rows:Array.from(body.querySelectorAll('[id^="row-"]')).map(e=>({id:e.id,cells:Array.from(e.children).map(c=>c.innerText),discount:e.querySelector('input[role="spinbutton"]')?.value,prefill:e.querySelector('input[role="spinbutton"]')?.getAttribute('data-prefill-id'),enabled:e.querySelector('[role="switch"]')?.getAttribute('aria-checked'),group:e.id.length<30?e.parentElement.innerText:null}))}));
  for(const r of b.rows){records.set(r.id,{...r,capturedAt:new Date().toISOString()});seenRows.add(r.id);if(r.group)seenProducts.add(r.id);}
  status.steps++;status.scroll={top:b.top,height:b.height,total:b.total};
  await persist();return b;
}
try {
  status.state='waiting_for_login';await persist();
  try {await page.goto(target,{waitUntil:'domcontentloaded',timeout:60000});}
  catch(e){status.state='waiting_for_network_or_login';status.navigationError=String(e);await persist();console.log('Initial navigation failed. The window remains open: refresh the target page or check the connection, then sign in.');}
  console.log('Please complete sign-in and any verification in this dedicated Chrome window. No password is entered by this script.');
  await waitForVerification();
  await page.screenshot({path:path.join(root,'login-state.png')});
  console.log(JSON.stringify({url:page.url(),visibleText:(await page.locator('body').innerText()).slice(0,1800)}));
  await page.locator('#promotion_name_input').waitFor({state:'visible',timeout:900000});
  const name=await page.locator('#promotion_name_input').inputValue();
  if(!name.trim())throw new Error('Activity name is empty.');
  if(!await page.getByRole('button',{name:'Arabellahair Arabellahair',exact:true}).isVisible())throw new Error('Target shop identity could not be verified.');
  status.activityName=name;status.shop='Arabellahair';status.state='collecting';await persist();
  await page.locator('.theme-arco-table-body').first().waitFor({state:'visible',timeout:60000});
  const countText=await page.locator('main').innerText();
  status.pageMetadata=countText.slice(0,2500);await persist();
  if(!countText.includes('Ongoing')||!countText.includes('Original price')||!countText.includes('Discount')||!countText.includes('Stock'))throw new Error('New activity status or table columns need verification.');
  const match=countText.match(/\b(\d+)\s+product\(s\)/);
  if(!match)throw new Error('Activity product count is unavailable.');
  status.expectedProducts=Number(match[1]);
  await page.screenshot({path:path.join(root,'activity-evidence.png'),fullPage:false});
  let pageNumber=1;
  const seenPages=new Set();
  while(pageNumber<=100){
    status.page=pageNumber;
    let previous=await capture();
    const pageKey=previous.rows.find(r=>r.group)?.id??previous.rows[0]?.id;
    if(seenPages.has(pageKey))throw new Error('A page repeated; pagination stopped to avoid an endless loop.');
    seenPages.add(pageKey);
    let stalled=0;
    for(let step=0;step<5000;step++){
      if(previous.top+previous.height>=previous.total-2)break;
      await waitForVerification();
      await page.locator('.theme-arco-table-body').first().evaluate(el=>el.focus()); await page.locator('.theme-arco-table-body').first().press('PageDown',{timeout:15000});
      await page.waitForTimeout(1000);
      const current=await capture();
      if(current.top<=previous.top+1){stalled++;if(stalled>=3)throw new Error('Scrolling stalled three times; checkpoint retained.');}
      else stalled=0;
      previous=current;
      if(step===4999)throw new Error('Per-page collection limit reached.');
    }
    if(seenProducts.size>=status.expectedProducts)break;
    const next=page.getByRole('listitem',{name:'Next',exact:true});
    if(!await next.count())throw new Error('Product coverage is incomplete and no Next page is available.');
    const disabled=await next.getAttribute('aria-disabled');
    const cls=await next.getAttribute('class');
    if(disabled==='true'||/disabled/.test(cls??''))throw new Error('Reached final page before all products were collected.');
    const oldFirst=previous.rows[0]?.id;
    await readOnlyClick(next);
    await page.waitForTimeout(1000);
    const changed=await page.locator('.theme-arco-table-body').first().evaluate(body=>body.querySelector('[id^="row-"]')?.id);
    if(changed===oldFirst)throw new Error('Next page did not change the table.');
    pageNumber++;
  }
  for(const key of records.keys())if(!seenRows.has(key))records.delete(key);
  await persist();
  status.state=status.discoveredProducts===status.expectedProducts&&seenProducts.size===status.expectedProducts&&status.incomplete.length===0?'complete':'incomplete';
  status.finishedAt=new Date().toISOString();await persist();
  await page.screenshot({path:path.join(root,'completion-evidence.png'),fullPage:false});
  console.log('Collection ended. The status file records whether all products and SKU counts reconcile.');
}catch(e){status.state='failed';status.error=String(e);await persist();console.error(e);process.exitCode=1;}
finally {await context.close();}

