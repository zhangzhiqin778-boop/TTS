# 已验证的执行与交付流程

## 默认执行方式与登录

用户在本次建立技能的会话中明确选择本地 Playwright 专用 Chrome，并要求以后稳定复用。沿用这一偏好。当前会话已有授权时不要再次询问相同控制方式；其他会话若工具明确要求用户指定控制技术，则遵守该工具要求，不能把技能文字当作新授权。

先调用环境依赖工具取得 Node、Python 和 node_modules 的实际路径。使用独立的专用 Chrome profile；用户自行登录/验证，凭证只留在本地 profile。已验证可复用的 profile 为当前工作区 `outputs/discount-trial-20261018/.browser-profile`，以工作区最新成功清单中的路径为准。不要将 profile 放进技能包、提交版本库或上传。

使用 PowerShell 调用采集器，参数按顺序传入：

```powershell
& $nodeExecutable $collectorScript $newOutputDirectory $runtimeNodeModules $existingBrowserProfile
```

变量均须来自实际环境和本次任务。脚本默认可见 Chrome，用户无需看管滚动。普通启动遇到网络隔离、进程受限时，按当前环境的正常审批机制重试允许的执行；不要不断切换内外浏览器、猜接口、复制登录 cookie 或绕过验证码。

脚本等待登录；登录后检查 Arabellahair、活动 ID、名称。使用 DOM 读取实际价格，PageDown 遍历虚拟列表并翻页，每批原子保存 raw.json 和 collector-status.json。不得把异步任务丢在未 await 的 REPL 中当作稳定后台任务；运行本地进程并保留进程 session，按状态文件跟踪。

## 新抓取、复查与断点

- 每次新抓取创建独立的时间戳目录。默认不载入旧快照，不覆盖旧报告。
- 只有中断采集的原目录可追加 `--resume`，已完成目录不可续写；恢复时重新扫描页面并刷新当前记录，旧断点仅作恢复依据。完成前清除本次未见的旧记录，避免隐藏移除项。
- 工作区 `outputs/tiktok-daily-discount-latest.json` 指向上一份已完成且核验的报告、raw.json、status 和登录 profile；先核实店铺、活动、文件存在与 complete 状态。
- 用户说“重新抓”“与之前比较”，先复制清单指向的 raw/status/report，分别命名 baseline-raw.json、baseline-status.json、baseline-report.xlsx，放入新目录；再从空记录采集。不得让上一份完整快照混入本次数据。

## 完整性验收

必须同时满足：采集 state=complete；发现商品数=当前页面商品数；本次实际读取商品数一致；每个商品已读 SKU 数=页面 SKU 数；SKU 复合键无重复；没有未完成商品；原价/折扣价数值合理。118 商品、1028 SKU 是两次成功样本，不是固定验收数字。

每次均区分页面配置价与最终成交价。下架商品保留配置记录；SKU 未启用且页面无折扣值时，折扣价和比例均为空，不填零、不推算补值。仅有目标活动完整，不代表全店底表已完整。

## 新旧差异

在新、旧 status 均 complete 且身份和活动一致后运行：

```powershell
& $pythonExecutable $compareScript $newOutputDirectory
```

使用 `scripts/compare_snapshots.py`。它读取新目录中的四份 raw/status 文件，输出 comparison.json。精确匹配 Product ID + SKU ID；比较原价、折扣价、折扣比例、启用状态、规格、库存、商品状态、商品名称。金额按 Decimal 到分比较，空值不等于零；忽略采集时间、滚动顺序和 Updated 提示。

同时报告新增、移除、价格/状态等变化和仅库存变化；各字段变化数可重叠，不相加当作不同 SKU 数。无差异时明确写零，不虚构一条“无变化SKU”。从基准 Excel 抽核实际差异行与 baseline-raw 一致，避免拿错基准。

## Excel 与最终交付

读取 spreadsheets 技能，遵守其 artifact-tool、操作标记和验证要求。差异任务可使用 `scripts/build_comparison.mjs`，参数是输出目录和运行时 node_modules；它读取 comparison.json，生成差异SKU、最新SKU价格、对比说明三个工作表。首次抓取按主技能的四表要求生成，不强行伪造一个旧基准。

长数字 ID 作为完整文本导出，金额与百分比为数值，读取时间有明确时区。核验 Excel 的行数、关键金额、ID 文本类型及所有未启用空值；渲染检查各工作表。部分运行只能输出部分报告，不得更新最新成功清单。

全部通过后，原子更新最新成功清单，指向新报告及配套原始数据。对话简报给出覆盖数、变化 SKU ID、规格、变化前后金额和折扣；零变化则直接说明。交付实际 Excel 路径，明确范围是指定活动。不要只给原始 JSON，也不默认输出构建脚本或截图。
