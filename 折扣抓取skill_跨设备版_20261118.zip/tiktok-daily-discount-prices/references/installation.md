# 跨设备安装与首次运行

1. 解压 ZIP，将整个 `tiktok-daily-discount-prices` 文件夹放到目标设备的 Codex 个人技能目录。默认位置：Windows 为 `%USERPROFILE%\.codex\skills\`，macOS/Linux 为 `~/.codex/skills/`；若配置了 CODEX_HOME，则使用该目录下的 `skills/`。
2. 在 Codex 新建会话，确认技能可用，输入“使用 $tiktok-daily-discount-prices 抓取日常折扣价格”。默认店铺是 Arabellahair，美国站，默认活动见 SKILL.md。其他店铺或活动应先明确目标并调整身份校验。
3. 新设备需要安装 Chrome，并在专用浏览器窗口手动登录 TikTok Shop。遇到验证码时手动完成，采集程序会等待；不会绕过验证码。
4. 本包包含技能说明与采集、比较、Excel 生成脚本，不包含 Node.js、Python、Playwright 或 Excel 生成依赖。优先由 Codex 的 load_workspace_dependencies 定位运行时；所需 Node 包为 playwright 和 @oai/artifact-tool。若目标环境缺少依赖，应先配置兼容运行时，不能直接套用源设备的绝对路径。
5. 首次运行使用目标设备上可写的全新输出目录与专用浏览器资料目录。execution.md 中旧运行目录仅是历史示例；不要假定它们存在。不要在不同设备共用浏览器资料目录。
6. 本包未包含历史报告与快照。首次采集没有基线时只输出本次结果；需要跨设备比较时，另行转移经核验的旧 raw.json、collector-status.json 及报告，并明确作为比较基线。不得把旧快照作为新采集结果。

包内不包含 Cookie、登录资料、浏览器 profile、店铺原始数据或历史 Excel。已包含验证码等待、断点恢复和完整覆盖核验逻辑；平台登录失效或验证码仍可能需要人工处理。
