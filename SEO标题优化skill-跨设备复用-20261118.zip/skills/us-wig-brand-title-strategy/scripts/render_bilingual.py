"""Render two aligned title rows as a PNG with shared phrase coordinates.

Input JSON: [{"en": "Arabellahair", "zh": "【Arabellahair】"}, ...]
Usage: python render_bilingual.py pairs.json output.png
"""

import argparse
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


FONT_CANDIDATES = (
    Path(r"C:\Windows\Fonts\msyh.ttc"),
    Path(r"C:\Windows\Fonts\simhei.ttf"),
    Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
    Path("/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc"),
    Path("/System/Library/Fonts/PingFang.ttc"),
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pairs", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--font", type=Path)
    parser.add_argument("--size", type=int, default=30)
    args = parser.parse_args()

    pairs = json.loads(args.pairs.read_text(encoding="utf-8"))
    if not isinstance(pairs, list) or not pairs:
        raise ValueError("Expected a nonempty list of {en, zh} pairs")
    for i, pair in enumerate(pairs):
        if not isinstance(pair, dict) or not pair.get("en") or not pair.get("zh"):
            raise ValueError(f"Pair {i} needs nonempty en and zh")
        if not pair["zh"].startswith("【") or not pair["zh"].endswith("】"):
            raise ValueError(f"Pair {i} must use 【Chinese】")
        if "\n" in pair["en"] or "\n" in pair["zh"]:
            raise ValueError("Each phrase must be one line")

    font_path = args.font or next((p for p in FONT_CANDIDATES if p.exists()), None)
    if font_path is None or not font_path.exists():
        raise FileNotFoundError("CJK font missing; pass --font with a CJK font path")
    font = ImageFont.truetype(str(font_path), args.size)
    left, gap, row_gap, top, bottom = 24, 24, 18, 20, 24

    def ink_mask(value: str) -> Image.Image:
        # Crop to the visible ink, not the font's advance box or side bearing.
        canvas = Image.new("L", (max(100, len(value) * args.size * 2), args.size * 3), 0)
        ImageDraw.Draw(canvas).text((args.size, args.size), value, font=font, fill=255)
        box = canvas.getbbox()
        if box is None:
            raise ValueError("A phrase rendered as blank ink")
        return canvas.crop(box)

    cells = []
    x = left
    row_height = 0
    for pair in pairs:
        en_mask = ink_mask(pair["en"])
        zh_mask = ink_mask(pair["zh"])
        row_height = max(row_height, en_mask.height, zh_mask.height)
        cells.append((x, en_mask, zh_mask))
        x += max(en_mask.width, zh_mask.width) + gap

    width = x - gap + left
    height = top + row_height * 2 + row_gap + bottom
    image = Image.new("RGB", (width, height), "#1d1d1f")
    color = "#f5f5f5"
    for x, en_mask, zh_mask in cells:
        image.paste(color, (x, top + (row_height - en_mask.height) // 2), en_mask)
        image.paste(
            color,
            (x, top + row_height + row_gap + (row_height - zh_mask.height) // 2),
            zh_mask,
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    image.save(args.output)
    # Coordinates are shared by construction. Output only nonsecret metadata.
    print(f"rendered {len(cells)} pairs; {width}x{height}; font={font_path.name}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"render failed: {exc}", file=sys.stderr)
        raise
