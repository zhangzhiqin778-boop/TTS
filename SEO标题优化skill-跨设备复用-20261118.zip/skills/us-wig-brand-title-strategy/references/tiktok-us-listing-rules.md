# TikTok Shop 美国站商品卡规则速查

核对日期：2026-11-14。用户给的跨境商家大学文章 `knowledge_id=8875523631843089` 当次无法直接读取；以下依据可访问的美国站 Seller University 官方页面，不能称作该文章原文。使用前留意规则更新和后台实际字段限制。

来源：
- [Product Listing Policy](https://seller-us.tiktok.com/university/essay?identity=1&knowledge_id=3196690250417921&role=1)：上架要求与禁止行为。
- [Product Detail Pages & Listing Quality Guidelines](https://seller-us.tiktok.com/university/essay?default_language=en&knowledge_id=481891871868714)：商品卡质量等级与优化建议。
- [Search terms and Product highlights](https://seller-us.tiktok.com/university/essay?knowledge_id=240361624880910)：两个字段的用途、写法与删除条件。

## 执行检查

1. 标题：使用有授权的正确品牌、真实商品类型和必要识别信息；准确、简洁、易读。不要重复堆叠、促销口号、库存宣称或未经证实的材质、工艺、功效。`Arabellahair` 放首位是本用户的品牌偏好，不是平台排名保证。平台政策要求尺寸、颜色信息放在变体标题，不放主标题；遇到单一款式或后台限制时，以当前规则和实际商品结构核对。质量指南的 25–255 字符属于质量评估区间，不等于鼓励写满。
2. 变体与属性：选准确类目、品牌，填写该类目要求的属性。长度、颜色、密度、蕾丝尺寸等必须与相应 SKU 一致，不把单个 SKU 的特性写成整条链接共有。变体要清晰且与主商品一致。
3. 图片：官方政策要求主图展示商品正面、纯白背景；商品图至少 600×600，不加文字、logo、水印、边框或促销图形；其他图片展示不同角度和真实细节。质量指南将至少 5 张清晰图片视为更高质量的方向。广告活动图若有折扣贴纸，不直接当商品卡主图。
4. 描述：把材质、结构、真实尺寸、佩戴方式、护理信息等写清楚，和标题、图片、SKU 一致。官方政策检查清单提到 30 词以上；质量指南另有 80 字符以上或描述图的质量指标。两者用途不同，实际写作以完整准确为先。
5. Search terms：后台关键词，用户不可见；补充真实相关的同义表达和标题未覆盖的购买词。用户当前编辑页显示 250 字符上限，实际填写按页面计数，相关性、准确性和去重优先，不为凑满加入无关词。平台可自动删除与商品不符或不合规内容。
6. Product highlights：商品详情页可见的简短卖点，官方建议 3–5 条，以已证实特征及购买价值写，不把关键词机械排列。用户当前编辑页显示 1500 字符上限；最终展示可能由平台生成或调整。平台可自动删除与商品不符或不合规内容。

## 假发标题特别核对

- 先辨别整顶 Lace Front、Half Wig、V/U Part、Bob 等商品形态，不混用。
- `Human Hair`、`Virgin`、`Raw Vietnamese`、`HD Lace`、`Pre-Cut`、`Glueless`、`Adjustable Drawstring` 等均需商品证据；不能仅因竞品使用就沿用。
- 避免 `Glueless ... Glueless Lace Wig ... Glueless Lace Wigs` 等同意重复；保留一次清晰表达。
- 为关键词补充给出竞品真实标题证据和自家商品事实，两者分开；同行频率不等于搜索量。
