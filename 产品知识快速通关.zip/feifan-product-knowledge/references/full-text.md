# 产品知识库提取全文

仅作检索；图片和版式以 PDF/页面图片为准。

## PDF 第 1 页

内容介绍
Content Introduction
Product knowledge
非凡成果-产品知识
授课老师：吴菲

## PDF 第 2 页

内容介绍
Content Introduction
2023年全球假发需求及
配饰搜索量稳重有升
4.37%

## PDF 第 3 页

内容介绍
Content Introduction
真人假发的需求仍然领先于合成纤维假发


## PDF 第 4 页

内容介绍
Content Introduction


## PDF 第 5 页

内容介绍
Content Introduction
发质类型
Hair type


## PDF 第 6 页

内容介绍
Content Introduction
01 发质类型
人造化纤就是在假发行业内部统称的化纤丝，
是指通过化学“抽丝”或者“吹丝”工艺制
作方法合成的化纤材料，类似于人发的假发
丝，是对人发原材料的一种补充。比较有名
的是日本的 kanekalon 和 toyokalon 。早
期使用较多的，最廉价的是PP料（也叫P料，
即聚丙烯化纤丝）
人工合成化纤丝中主要包括：常温丝，高温
丝，蛋白丝等几种常品类；
又根据其产地不同可细分为国产丝、日丝、
韩丝等等；
根据其反光度不同还可分为普通丝、哑光丝
化
纤
发


## PDF 第 7 页

内容介绍
Content Introduction
01 发质类型
 产地：
中国发，印度发，巴西发，缅甸发，越南发，蒙古发等等
因其材质原因，可烫可染，易于保存，但人发产量有限，
人发产品在价格上要稍微昂贵一些。
各地区的人发的主要区别在于发质与曲度上，中国发，蒙
古发，缅甸发，越南发同属亚洲人发质，发质较粗直，其
中以中国发最优，中国发手感顺滑，价格最贵。巴西发与
印度发在发质上较为柔软，曲度稍大，适用于欧美人发型，
多用于接发，其中以巴西发为最优。
 分类：
1.泡发 non remy （不主推）
2.顺发 remy 
3.辫发 virgin hair 
真
人
发  产
品
主
要
原
料

## PDF 第 8 页

内容介绍
Content Introduction
01 发质类型
原料 价格 使用时间 触感和视觉 性能 梳理 清洗 造型 色彩
化纤 低廉 基本一次
性
条粗硬，假
亮光
不可染色 容易打结 清洗后基本
不能用
造型持久，
不易变形
色彩鲜亮，
颜色无限制
人发 昂贵 6个月到
一年
柔软，自然 可染可漂、
可烫卷曲
不易打结，
可梳开
可多次清洗，
晾干后继续
使用
曲度越大，
越容易伸直
颜色较暗沉，
受发质限制

## PDF 第 9 页

内容介绍
Content Introduction
01 发质类型
燃烧实验：
真人发燃烧后手指轻搓成灰沫状
化纤丝成团装，有塑料味道


## PDF 第 10 页

内容介绍
Content Introduction


## PDF 第 11 页

内容介绍
Content Introduction
01 发质类型

## PDF 第 12 页

内容介绍
Content Introduction
产品分类
CLASSIFICATION


## PDF 第 13 页

内容介绍
Content Introduction
发条/发帘
英文描述为：hair bundle/hair 
weave/hair weaving/hair weft
头套
英文描述为：wig/hair wig/human 
hair wig
发块
英文描述为：closure
02 产品分类
注意：在亚马逊中，以上三者不在一个类目
发条/发帘、卡子发、棒棒发、指甲发、胶片发等，属于接发类目，Hair Extensions
头套属于补发/替换发类目，Hair Replacement Wigs

## PDF 第 14 页

内容介绍
Content Introduction
发条/发帘
发帘重量95-100g
02 产品分类
双层帘子边
Double welf
展开图

## PDF 第 15 页

内容介绍
Content Introduction
发条/发帘组合
02 产品分类
发条属于半成品，单独一条的发帘不能组成一个头套，一个高密度的头套大约需要
2.5—3条90—100g左右的发帘。
使用方法：
1、客户将自己的头发编成贴头皮的小辫子，用钩针直接将发条固定在辫子上。
2、购买头套内网自己缝制成头套。


## PDF 第 16 页

内容介绍
Content Introduction
02 产品分类
接发类目其他产品
常见的有：卡子发、棒棒发、指甲发
胶片发等
Clip in
 Tape in

## PDF 第 17 页

内容介绍
Content Introduction
-曲度和颜色03 造型分类


## PDF 第 18 页

内容介绍
Content Introduction
-曲度和颜色03 造型分类


## PDF 第 19 页

内容介绍
Content Introduction
-曲度和颜色03 造型分类


## PDF 第 20 页

内容介绍
Content Introduction
-曲度和颜色03 造型分类


## PDF 第 21 页

内容介绍
Content Introduction
发块
4*4 
closure
 4*4发块
2*6 closure
2*6发块（主推）
 13*4 lace frontal 
13*4发块（主推）
360 lace closure 
360发块（主推）
 
02 产品分类

## PDF 第 22 页

内容介绍
Content Introduction
头套
02 产品分类
直接可佩戴，安装快捷方便
根据蕾丝面积可分为：4x4、
5x6、6x7、7x9、13x4、13x6、
360、全蕾丝等

## PDF 第 23 页

内容介绍
Content Introduction
头套按蕾丝面积分类
02 产品分类


## PDF 第 24 页

内容介绍
Content Introduction
头套按蕾丝面积分类
02 产品分类
 360

## PDF 第 25 页

内容介绍
Content Introduction
头套按蕾丝面积分类
02 产品分类


## PDF 第 26 页

内容介绍
Content Introduction
头套按曲度分类
02 产品分类


## PDF 第 27 页

内容介绍
Content Introduction
头套按曲度分类
02 产品分类


## PDF 第 28 页

内容介绍
Content Introduction
头套的卖点介绍
02 产品分类
Pre-plucked Natural Hairline
Pre-cut lace
贴合度


## PDF 第 29 页

内容介绍
Content Introduction
头套的卖点介绍--漂扣
02 产品分类
在SKU中，用W表示

## PDF 第 30 页

内容介绍
Content Introduction
头套的卖点介绍
02 产品分类


## PDF 第 31 页

内容介绍
Content Introduction
头套的卖点介绍——无胶假发wear& go /glueless
02 产品分类


## PDF 第 32 页

内容介绍
Content Introduction
True to length
Soft & shiny
Tangle & shed free
No smell      
Long life span
Bleach & Dye & Perm
Hold the texture well            
Amplitude
Miscellaneous hair and 
impurities 
忠实于长度
柔软有光泽
无缠结和脱落
没有气味
寿命长
漂白剂、染料和烫发剂
很好地保持纹理
幅度
杂发和杂质 
05 产品卖点

## PDF 第 33 页

内容介绍
Content Introduction
幅度（档次）
幅度：幅度也就是所谓的档次，幅度是指产品的头上和发尾的粗细不同。
正确的分档，是按照百分比分的，比如:一档本档尺寸比例100%，二档包含本档尺寸
及下档尺寸两个档位，本档尺寸比例50%，三挡包含本档及以下两个档位，本档比例
33%，以此类推。可是市面上，几乎没有按照这种比例生产产品的了。
single 
drawn=10A-
HW-N-ST-
18
double 
drawn=15A-
HW-N-ST-
18
幅度越好，尾部越厚，价
格越贵。
02 产品分类

## PDF 第 34 页

内容介绍
Content Introduction
-曲度和颜色
03 造型分类

## PDF 第 35 页

内容介绍
Content Introduction
-曲度和颜色-常见颜色
N#
 4#
 33#
 613#
 99J#
P色系：即Piano色，常见的有P#,1BP30#,P27#,Balayage#,P10/613#,P12/613#等
T色：上下层色，常见的有1B99J#等
P10/613# 1BP30# Balayage#
 1B99J#
 T4/613#
03 造型分类

## PDF 第 36 页

内容介绍
Content Introduction


## PDF 第 37 页

内容介绍
Content Introduction
影响价格的因素


## PDF 第 38 页

内容介绍
Content Introduction
影响价格的因素
1.尺寸
尺寸越长，原材料价格越高，相应的产品价格也就越贵。
真人发采购是按照一定的长短档比列来计算成本，
长尺寸价格昂贵且稀少。
2.幅度
幅度越好价格越贵
幅度好就说明产品的本档占比高，发尾更厚实。
04

## PDF 第 39 页

内容介绍
Content Introduction
影响价格的因素04

## PDF 第 40 页

内容介绍
Content Introduction
3.蕾丝面积
蕾丝面积越大，价格越贵。
蕾丝面积大小其实就是手织部分的多少，手织部分越多，人工费越高，价格也就越昂贵。
手织面积的影响还包括手织格式（勾一空一、勾一空二、勾一空三）
影响价格的因素04

## PDF 第 41 页

内容介绍
Content Introduction
4.密度
密度越高，价格越贵
密度指手织部分的密度和机制部分的密度，密度可以理解为发量，发量高的价格贵。
5.蕾丝
蕾丝分为国产蕾丝、进口蕾丝、一般蕾丝和HD高清蕾丝
影响价格的因素04

## PDF 第 42 页

内容介绍
Content Introduction
客诉集中点


## PDF 第 43 页

内容介绍
Content Introduction
客诉集中点
1.尺寸
因为尺寸是影响价格的第一因素，所以也是客诉最多的。
需要明确告知客户尺寸测量的正确方式，且严格把控产品的尺寸质检。
2.密度
客户对幅度和密度没有明确的概念，所以当产品发量或者幅度分布不均匀时候，客户都会留下密度
的差评。
因为假发是非标品，密度问题无法通过测量等给出标准数值，所以平台上密度标准混乱，卖家和客
户都无法准确定位准确密度，需多看竞对，尽量写出合理产品密度。
3.脱落纠缠打结
因为人发产品客单价较高，客户不能忍受高价买到的产品会脱落慢慢变少，所以对于头发的脱落也
是客户非常介意的。
05

## PDF 第 44 页

内容介绍
Content Introduction
关于脱落，和以下几点有直接关系：
①客户使用方法和护理程度，如果比较专业的客户，能够很好的掌握洗护方法，会有效减少脱落现
象
②曲度、曲度越小，越容易打结脱发，首先小曲度产品容易打结，打结后容易脱落；其次曲度越小
要保持曲度就需要定型时间越长，这样会造成发质变的容易断发，客户会认为是脱发
③颜色、颜色漂的越浅，发质受损越严重，也会造成脱发现象
4.实物不符合
产品与描述不符合或者产品与图片不符合，由于是线上购买，客户无法直接接触到产品，所以只能
通过文字描述和图片来判断，当客户收到的产品与心理预期不符合的时候，就会有不好的评价
针对这个需要我们尽量合理的真实描述产品，图片不可修图太夸张，尽量突出产品的卖点，不可夸
大太多
客诉集中点05

## PDF 第 45 页

内容介绍
Content Introduction
生产流程
production process


## PDF 第 46 页

内容介绍
Content Introduction


## PDF 第 47 页

内容介绍
Content Introduction
发条/发帘生产流程
 生料库：购买原材料入库--原材料试验--挑白条--顺头--配货出库
 前处理：排发--过酸--中和--漂色--洗中和--染色--洗发--泡油--上篦子--装
坑烘干
 色发库：前处理完成好的色发入库--配货--检验配货--下打发车间生产
 打发：在色发库领料后，将各种颜色、尺寸按所需比例混合均匀，制作成发把
 三联机：分间色--三联机排帘子--梳通--清理毛球球
 后处理+美容（针对曲发）：美容缠管定型--高针--定型--转后处理--二次泡油-
-梳曲度--烘干
（手工：根据产品规格说明书要求手工制作各种曲度：拧两股辫，辫三股辫子，缠管；
手织：根据手织设计图纸对照帽网画好手织样板，把帽网订平整，按照图纸上手织分
布把头发按尺寸一根根织在帽皮上）
 高针：高针机就是在缝纫机的基础上增加一个贴合网帽弧度的碗状金属来支网帽；
发帘分好档次（就是长度），按照作业指导书的要求行距均匀，针脚细密的车在
网帽上；组合头套：将准备好的发块和网帽扎在一起，发帘 一行行均匀的扎在网
帽上
 完成：修帽子--剪蕾丝网--吹风--梳发--熨烫--整理曲度--套网
 包装：将做好的产品套网装入包装材料，套袋子。
06 发条/发帘生产流程

## PDF 第 48 页

内容介绍
Content Introduction
假发的护理
Wig care


## PDF 第 49 页

内容介绍
Content Introduction


## PDF 第 50 页

内容介绍
Content Introduction
SKU的构成
SKU differentiation


## PDF 第 51 页

内容介绍
Content Introduction
等级区分：
7A：压色泡发
8A：压色顺发
10A：顺发，幅度中等
13A：保麟辨发+顺发
15A：顺发一档货
16A：辫发一档货
注：压色浅染黑，比N#黑，通常为1B#/1#色
08 SKU的区分

## PDF 第 52 页

内容介绍
Content Introduction
  
08 SKU的区分
2.发条编制规则
           等级            -HW-        颜色-        曲度-       尺寸
1.发条：HW（hair weaving/hair weft）
7A：压色泡发
8A：压色顺发
10A：顺发，幅度中等
13A：保麟辨发+顺发
15A：顺发一档货
16A：辫发一档货
HW
hair 
weaving
hair weft
N#
1#
4#
33#
613#
P10/613#
T4/613#
ST-直发
WATER-水波
BODY WAVE
LOOSE WAVE
DEEP
JC
Kindy curly

## PDF 第 53 页

内容介绍
Content Introduction
例：10A-HW-N-ST-16
    
    10A发条直发自然色16inch

## PDF 第 54 页

内容介绍
Content Introduction
08 SKU的区分
TS:透明网顺
发
S:普通网顺发
HD：HD
（高清）蕾丝
1.发块编制规则
   蕾丝                     -面积                         -颜色                -曲度        
-尺寸
HC：4*4  （Clouse）
HF：13*4   （frontal）
H136：13*6
H360：360
H55：5*5
HCF：44自由分(free）
HFM：134中分（mid)
H55T：55三分(three）
N#
1#
4#
33#
613#
P10/613#
T4/613#
ST-直发
WATER-水波
BODY WAVE
LOOSE WAVE
DEEP
JC
Kindy curly

## PDF 第 55 页

内容介绍
Content Introduction
例：TS-HCF-N-ST-20
透明网顺发 4*4自由分 N# 直发 20inch发块


## PDF 第 56 页

内容介绍
Content Introduction
08 SKU的区分
蕾丝面积         -WIG       -颜色           -曲度        -尺寸
1.发帽：WIG
2.发帽编制规则
• W：漂扣
• F：标品
• FA：亚马逊标品/引流款
• FB(56)/FD：标品bob
• FTB(134)/FD：标品134bob
• WQ/Q32：3*2小蕾丝（漂扣）
• HS：升级顺发
• K：加密产品
发帽 N#
1#
4#
33#
613#
P10/613#
T4/613#
ST-直发
WATER-水波
BODY WAVE
LOOSE WAVE
DEEP
JC
Kindy curly

## PDF 第 57 页

内容介绍
Content Introduction
例：F134-WIG-N-ST-22
08 SKU的区分
   标品134自然色直发22inch发帽


## PDF 第 58 页

内容介绍
Content Introduction
前缀简要描述 
• NS：新网帽
• NC：新网帽
• HD：瑞士网顺发
• TB：透明网辨发
• S：顺发
• C：C货
• KC：
• SFL：全蕾丝
08 SKU的区分

## PDF 第 59 页

内容介绍
Content Introduction
• 134
• 44
• 55
• 136
• 56
• 360
• 机制
• 其他（T/V/L/U): 字母即为蕾丝面积
（例：U-part-WIG-N-BW-12 U形发套 N# BW造型 12)
08 SKU的区分
机制：
1.SM（Q/P/M) Q齐刘海；P偏分；
M中分
2.SMH/SQH 机制头巾
3.BMQ 机制bob
4.BMH 机制头巾bob

## PDF 第 60 页

内容介绍
Content Introduction
 发货仓库及发货物流
发货仓库及发货物流：
目前公司共有两个发货仓库，美国仓和许昌华硕主仓，美国仓主要发美
国订单，许昌华硕主仓可以发美国订单及欧洲等国家订单.
发货物流：
 美国订单：FEDEX/ 
DHL
 加拿大及法国订单：
DHL 
 德国、比利时、意大
利、西班牙：TNT
 英国：GES
 其它：其它物流


## PDF 第 61 页

内容介绍
Content Introduction
 FBA发货：属于重货，运输方式为：UPS红单、空派、海派。
红单时效一般5-7天到达FBA仓库
空派时效一般9-15天到达FBA仓库
海派时效一般21-30天到达FBA仓库
价格：红单＞空派＞海派
体积重：红单/5000    空派/6000
亚马逊发货：

## PDF 第 62 页

内容介绍
Content Introduction
各物流查询链接：
 GES:https://www.17track.net/zh-cn
 TNT:https://www.tnt.com/express/zh
_cn/site/home.html
 DHL:https://track.dhlparcel.co.uk/
 FedEx：https://www.fedex.com/zh-
cn/home.html
 USPS:https://zh.usps.com/
 其它快递：登录官网查询
其它问题：
 索赔问题
 称重图：可直接对接物流部要称重图
 RMA退货管理：退货都退回到许昌仓库，没有走系统，有共享文
档
 退货标签：亚马逊有个退货单号打印，可以申请退货标签。

## PDF 第 63 页

内容介绍
Content Introduction
THANK YOU
感谢您的观看

