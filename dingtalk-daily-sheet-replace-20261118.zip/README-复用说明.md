# 钉钉每日库存与销量覆盖：跨设备复用

## 包内内容

- `dingtalk-daily-sheet-replace/SKILL.md`：当前已安装的完整技能说明，原样保留。
- `dingtalk-daily-sheet-replace/agents/openai.yaml`：技能显示名称与调用提示。
- 本说明文件。

不包含登录凭据、Token、账号配置、订单或库存源数据、历史备份、设备专用脚本和 DWS 可执行文件。

## 在另一台设备上使用

最省事的方法：把整个 ZIP 提供给新设备上的 Codex，并发送：

> 请安装压缩包里的 dingtalk-daily-sheet-replace 技能，检查 DWS 依赖，并协助我完成钉钉登录。暂不修改在线数据。

也可以手动把包内 `dingtalk-daily-sheet-replace` 文件夹复制到该设备的 Codex 用户技能目录。默认目录为 Windows 的 `%USERPROFILE%\.codex\skills\`，或 macOS/Linux 的 `~/.codex/skills/`；若设置了 CODEX_HOME，则放到其 `skills` 子目录。不要多嵌套一层文件夹，也不要覆盖未经核对的同名技能。

安装后在下一轮对话中调用技能；若没有识别，重新打开聊天或应用后再试。

## 钉钉连接

新设备需安装适合其操作系统的 DWS，并独立登录。官方项目：https://github.com/DingTalk-Real-AI/dingtalk-workspace-cli

安装完成后检查 `dws --version`，再执行 `dws auth login`。用户本人完成扫码授权，随后用 `dws auth status --format json` 确认登录。浏览器没有打开时，打开该次命令输出的授权链接；不要使用其他设备或旧会话的回调链接。不要复制旧设备的凭据文件。

登录账号必须能访问并编辑技能指定的工作簿。表格解析环境还需能读取 XLSX 和 CSV。新设备第一次运行时须核实当前接口参数、实际 sheet ID、表头与覆盖范围；不能照搬历史行数或本机绝对路径。

## 日常调用

每次提供当天的库存 XLSX 和近30天销量 CSV，再发送：

> 使用 $dingtalk-daily-sheet-replace，用这两个当天文件更新库存与近30天销量。先备份，全量覆盖对应子表，清除旧尾部，并完整回读核验。

默认目标仍为技能中记录的「库存同步+备货需求」，仅更新「库存-每日9点左右」「30天销量截止-最新版」。迁移到其他工作簿时，必须先由用户明确提供新链接与对应子表名称。技能中的流程说明不构成对其他工作簿的操作授权。

工作簿链接随技能一起打包，但包本身不授予访问权限。不会自动定时执行；每次更新由用户提供源文件触发。
