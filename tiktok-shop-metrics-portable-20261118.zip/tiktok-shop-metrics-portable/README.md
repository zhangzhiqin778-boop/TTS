# 跨设备使用

将整个 `tiktok-shop-metrics-portable` 文件夹放入支持 Skills 的 AI 技能目录，或直接把 `SKILL.md` 上传给其他 AI，并连同 `references` 文件夹一起提供。之后上传订单/售后表即可按其中口径计算。

`references/product_aliases.csv` 保存最新 PID 排序；`references/sku_pid_mapping.csv` 保存SKU映射。新增/改名商品时需更新映射文件并重新分发整个文件夹。

本包只含规则和映射，不含任何订单、客户或店铺交易数据。
