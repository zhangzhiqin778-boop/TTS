"""Daily GMV and a simple peak-day forecast for a TikTok Shop PID."""
import argparse
import csv
import json
from collections import defaultdict
from datetime import datetime, timedelta
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path

money=lambda x:str(x.quantize(D('.01'),rounding=ROUND_HALF_UP))

def main(a):
    daily=defaultdict(lambda:{'qty':0,'before':D(0),'seller_discount':D(0),'platform_discount':D(0),'gmv':D(0),'rows':0})
    excluded=0; matched=0
    with Path(a.orders).open(encoding=a.encoding,newline='') as f:
        reader=csv.DictReader(f)
        required={'Product ID','Order Status','Created Time','Quantity','SKU Subtotal Before Discount','SKU Seller Discount'}
        if not required.issubset(reader.fieldnames or []):raise ValueError('订单表缺少字段：'+','.join(sorted(required-set(reader.fieldnames or []))))
        has_platform='SKU Platform Discount' in reader.fieldnames
        for r in reader:
            if (r.get('Product ID') or '').strip()!=a.pid:continue
            matched+=1
            if (r.get('Order Status') or '').strip()=='Canceled':excluded+=1;continue
            dt=datetime.strptime((r['Created Time'] or '').strip(),'%m/%d/%Y %I:%M:%S %p').date()
            qty=int(D((r['Quantity'] or '').strip().replace(',','')))
            before=D((r['SKU Subtotal Before Discount'] or '').strip().replace(',',''))
            seller=D((r['SKU Seller Discount'] or '0').strip().replace(',',''))
            platform=D((r.get('SKU Platform Discount') or '0').strip().replace(',','')) if has_platform else D(0)
            g=daily[dt];g['qty']+=qty;g['before']+=before;g['seller_discount']+=seller;g['platform_discount']+=platform;g['gmv']+=before-seller-platform;g['rows']+=1
    if not daily:raise ValueError('指定 PID 没有有效订单')
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    with (out/'每日GMV.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['日期','销量','折前商品金额_USD','商家折扣_USD','平台折扣_USD','GMV_USD','订单行数'])
        for day,g in sorted(daily.items()):w.writerow([day.isoformat(),g['qty'],money(g['before']),money(g['seller_discount']),money(g['platform_discount']),money(g['gmv']),g['rows']])
    end=max(daily); recent=[daily.get(end-timedelta(days=i),{}).get('gmv',D(0)) for i in range(7)]
    baseline=sum(recent,D(0))/7
    peak=max(g['gmv'] for g in daily.values())
    future_days=a.horizon
    month_end=end.replace(day=28)+timedelta(days=4);month_end=month_end-timedelta(days=month_end.day)
    remaining=(month_end-end).days
    def forecast(days):
        peakdays=min(a.peaks,days)
        return {'days':days,'peak_days':peakdays,'peak_gmv_assumption_usd':money(D(str(a.peak_gmv)) if a.peak_gmv is not None else peak),
                'baseline_daily_gmv_usd':money(baseline),'forecast_gmv_usd':money((D(str(a.peak_gmv)) if a.peak_gmv is not None else peak)*peakdays+baseline*(days-peakdays))}
    total_qty=sum(g['qty'] for g in daily.values());total_gmv=sum((g['gmv'] for g in daily.values()),D(0))
    qty_peak=max(g['qty'] for g in daily.values());gmv_peak=peak
    result={'pid':a.pid,'date_start':min(daily).isoformat(),'date_end':end.isoformat(),'matched_rows':matched,'excluded_canceled_rows':excluded,
        'quantity':total_qty,'gmv_usd':money(total_gmv),'gmv_basis':'折前商品金额-商家折扣-平台折扣','platform_discount_field_present':has_platform,
        'quantity_peak_days':[d.isoformat() for d,g in daily.items() if g['qty']==qty_peak],'quantity_peak':qty_peak,
        'gmv_peak_days':[d.isoformat() for d,g in daily.items() if g['gmv']==gmv_peak],'gmv_peak_usd':money(gmv_peak),
        'forecast_assumption':'最近7个自然日均值作为非峰值基准；峰值沿用历史单日最高或用户输入。',
        'next_horizon':forecast(future_days),'remaining_current_month':forecast(remaining)}
    (out/'趋势预测.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--orders',required=True);p.add_argument('--pid',required=True);p.add_argument('--output',required=True)
    p.add_argument('--peaks',type=int,default=2);p.add_argument('--peak-gmv',type=float);p.add_argument('--horizon',type=int,default=7);p.add_argument('--encoding',default='utf-8-sig')
    main(p.parse_args())
